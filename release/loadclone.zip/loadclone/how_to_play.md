# How To Play

## How To Win

Colect all the gold in each level and then go to the exit. Don't die too many times :)

You can dig holes in the ground but they refill. If you in the hole when it reforms, you will die.


## Controls

### Player

* Number Pad 4 - Move Left
* Number Pad 6 - Move Right
* Number Pad 8 - Climb Up Ladder
* Number Pad 5 - Climb Up Ladder and Let Go of Overhead Bars
* Number Pad 7 - Dig Left
* Number Pad 9 - Dig Right

For right now controls are not reconfigureable

### Game

* r   - Restart Level
* Esc - Exit Game

## Configuration

Look at config_template.txt for descriptions of paramiters you can use
to configure the game.

Just create a config.txt file and copy in what you want, or rename the
config_template.txt file.

